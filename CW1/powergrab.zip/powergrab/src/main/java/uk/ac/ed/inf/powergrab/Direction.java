package uk.ac.ed.inf.powergrab;

public enum Direction {
	// Define constants for all sixteen compass directions
	N, NNE, NE, ENE, E, ESE, SE, SSE, 
	S, SSW, SW, WSW, W, WNW, NW, NNW;
}
